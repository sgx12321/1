#!/bin/sh
# Modem File Box server v5
# PUT body is raw binary. The shell 'read' builtin is the only reader that
# blocks correctly on this non-blocking socat socket, so it is used for the
# request line + headers only (read consumes byte-wise, no over-read).
# The raw body that remains on stdin is then copied to the target file by
# socat itself (-u FD:0 -> OPEN), which polls non-blocking fds properly.
# busybox dd reads 0 bytes, cat hangs forever, awk/printf cannot emit NUL.
trap '' PIPE
BASE=/opt/upt/apps/filemgr
DIR=$BASE/data
SOCAT=/userconfig/socat
MAXF=52428800
MAXT=52428800

resp() { printf 'HTTP/1.0 %s\r\nContent-Type: %s\r\nConnection: close\r\n' "$1" "$2"; }
bad() { resp "400 Bad Request" "text/plain"; printf '\r\nbad request'; exit 0; }

read R
R=$(echo "$R" | tr -d '\r')
M=$(echo "$R" | cut -d' ' -f1)
P=$(echo "$R" | cut -d' ' -f2)
[ -z "$P" ] && exit 0
Q=""
case "$P" in
  *\?*) Q=${P#*\?}; P=${P%%\?*} ;;
esac
F=""
case "$Q" in
  f=*) F=${Q#f=} ;;
esac

CL=0
while read H; do
  H=$(echo "$H" | tr -d '\r')
  [ -z "$H" ] && break
  case "$H" in
    [Cc]ontent-[Ll]ength:*) CL=$(echo "$H" | cut -d: -f2 | tr -d ' ') ;;
  esac
done
case "$CL" in ''|*[!0-9]*) CL=0 ;; esac

needname() {
  case "$F" in
    ""|.*|*..*|*[!a-zA-Z0-9._-]*) bad ;;
  esac
}

dirtotal() {
  T=0
  for X in "$DIR"/*; do
    [ -f "$X" ] || continue
    case "$X" in */.*) continue ;; esac
    S=$(wc -c < "$X" | tr -d ' ')
    T=$((T+S))
  done
  echo $T
}

case "$P" in
  /)
    resp "200 OK" "text/html; charset=utf-8"
    printf '\r\n'
    cat "$BASE/page.html"
    ;;
  /sjcl.js)
    resp "200 OK" "application/javascript"
    printf '\r\n'
    cat "$BASE/sjcl.js"
    ;;
  /api/list)
    L=""
    N=0
    TOT=0
    cd "$DIR" || exit 0
    for X in *; do
      [ -f "$X" ] || continue
      case "$X" in .*|*..*|*[!a-zA-Z0-9._-]*|*.bak-*) continue ;; esac
      S=$(wc -c < "$X" | tr -d ' ')
      TOT=$((TOT+S))
      BL=""
      K=0
      for B in $(ls -r "$X".bak-* 2>/dev/null); do
        TS=${B##*.bak-}
        [ "$K" = 1 ] && BL="$BL,"
        BL="$BL\"$TS\""
        K=1
      done
      [ "$N" = 1 ] && L="$L,"
      L="$L{\"name\":\"$X\",\"size\":$S,\"baks\":[$BL]}"
      N=1
    done
    resp "200 OK" "application/json"
    printf '\r\n{"total":%s,"max":%s,"files":[%s]}' "$TOT" "$MAXT" "$L"
    ;;
  /api/get)
    needname
    if [ ! -f "$DIR/$F" ]; then resp "404 Not Found" "text/plain"; printf '\r\nnot found'; exit 0; fi
    S=$(wc -c < "$DIR/$F" | tr -d ' ')
    resp "200 OK" "application/octet-stream"
    printf 'Content-Length: %s\r\nContent-Disposition: attachment; filename="%s"\r\n\r\n' "$S" "$F"
    $SOCAT -u -T 2 FILE:"$DIR/$F" FD:1 2>/dev/null
    ;;
  /api/put)
    needname
    if [ "$M" != "PUT" ]; then resp "405 Method Not Allowed" "text/plain"; printf '\r\nput only'; exit 0; fi
    if [ "$CL" -gt "$MAXF" ]; then resp "413 Too Large" "text/plain"; printf '\r\nfile too large'; exit 0; fi
    T="$DIR/.up$$"
    $SOCAT -u -T 2 FD:0 OPEN:"$T",creat,trunc 2>/dev/null
    S=0
    [ -f "$T" ] && S=$(wc -c < "$T" | tr -d ' ')
    if [ "$S" != "$CL" ]; then rm -f "$T"; resp "400 Bad Request" "text/plain"; printf '\r\nincomplete'; exit 0; fi
    TOT=$(dirtotal)
    if [ $((TOT+S)) -gt "$MAXT" ]; then rm -f "$T"; resp "413 Too Large" "text/plain"; printf '\r\nquota full'; exit 0; fi
    if [ -f "$DIR/$F" ]; then
      TS=$(date +%Y%m%d%H%M%S)
      cp "$DIR/$F" "$DIR/$F.bak-$TS"
      CNT=$(ls "$DIR/$F".bak-* 2>/dev/null | wc -l | tr -d ' ')
      while [ "$CNT" -gt 2 ]; do
        OLD=$(ls "$DIR/$F".bak-* | sed -n 1p)
        rm -f "$OLD"
        CNT=$((CNT-1))
      done
    fi
    mv "$T" "$DIR/$F"
    resp "200 OK" "text/plain"
    printf '\r\nok'
    ;;
  /api/del)
    needname
    rm -f "$DIR/$F" "$DIR/$F".bak-*
    resp "200 OK" "text/plain"
    printf '\r\nok'
    ;;
  *)
    resp "200 OK" "text/html; charset=utf-8"
    printf '\r\n'
    cat "$BASE/page.html"
    ;;
esac
exit 0
